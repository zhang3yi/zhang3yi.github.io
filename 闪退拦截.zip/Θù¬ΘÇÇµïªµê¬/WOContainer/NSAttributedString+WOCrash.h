//
//  NSAttributedString+WOCrash.h
//  GridGovernance
//
//  Created by 吴欧 on 2017/12/21.
//  Copyright © 2017年 Bitvalue. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSAttributedString (WOCrash)

+ (void)wo_enableAttributedStringProtector;

@end
